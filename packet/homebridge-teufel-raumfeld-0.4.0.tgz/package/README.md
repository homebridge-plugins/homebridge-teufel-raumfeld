<p align="center">
  <img src="https://raw.githubusercontent.com/homebridge/branding/master/logos/homebridge-wordmark-logo-vertical.png" width="150">
</p>

# homebridge-teufel-raumfeld

**Raumfeld, in Apple Home.**

A [Homebridge](https://homebridge.io) plugin that exposes your Teufel Raumfeld
multiroom speakers to Apple HomeKit — every room as a tile, every Raumfeld group
as a single controllable accessory, with optional AirPlay streaming from any
iPhone.

```sh
npm install -g homebridge-teufel-raumfeld
```

![npm](https://img.shields.io/npm/v/homebridge-teufel-raumfeld) ![license](https://img.shields.io/badge/license-MIT-blue) ![homebridge](https://img.shields.io/badge/homebridge-%3E%3D1.8-blueviolet)

## Features

- **Auto-discovery** — finds the Raumfeld host on your network (SSDP), or point it at a fixed IP.
- **Native Home tiles** — each room appears as a HomeKit speaker with volume, mute and play/pause.
- **Multiroom groups** — groups you make in the Raumfeld app show up as one accessory; member rooms are controlled together (see below).
- **Per-zone volume** — HomeKit volume maps to Raumfeld volume; group volume can be kept in sync.
- **AirPlay streaming** *(optional)* — advertise zones as AirPlay receivers to stream straight from iOS.
- **Siri** — “Hey Siri, set the Kitchen to 30%.”
- **Cross-subnet friendly** — resolves speakers via the host’s HTTP API, so Homebridge and the speakers can live on different VLANs.

## Configuration

Configure from the Homebridge Config UI X screen (a custom settings page ships
with the plugin), or add a platform block to `config.json`:

```json
{
  "platforms": [
    {
      "platform": "Raumfeld",
      "name": "Raumfeld",
      "autoDiscover": true,
      "host": "192.168.1.50",
      "pollInterval": 30,
      "airplay":   { "enabled": true },
      "multiroom": { "exposeGroups": true, "syncGroupVolume": true }
    }
  ]
}
```

| Option | Default | Description |
|---|---|---|
| `autoDiscover` | `true` | Find the Raumfeld host via SSDP. Turn off to use `host`. |
| `host` | — | IP/hostname of the Raumfeld host. Required when `autoDiscover` is off, or when Homebridge and the speakers are on different subnets (SSDP can’t cross subnets). |
| `pollInterval` | `30` | Safety-net poll seconds (30–60); live group changes arrive instantly via the host long-poll. |
| `airplay.enabled` | `true` | Advertise zones as AirPlay receivers. Requires `shairport-sync` on the host — see [AirPlay streaming](#airplay-streaming). |
| `airplay.binaryPath` | `shairport-sync` | Path to the `shairport-sync` binary. Default finds it on `PATH`. |
| `airplay.password` | — | Password iOS must enter to stream to these zones. **Blank leaves every zone an open AirPlay receiver** — see [AirPlay streaming](#airplay-streaming). |
| `airplay.streamHost` | auto | IP/hostname the speakers use to reach this Homebridge machine's audio stream. Auto-detected; set it when Homebridge and the speakers are on **different subnets**. |
| `airplay.streamPort` | `8099` | TCP port for the local audio stream the speakers pull from. |
| `multiroom.exposeGroups` | `true` | Expose active Raumfeld groups as accessories. |
| `multiroom.syncGroupVolume` | `true` | Apply group volume changes to all members. |

Restart Homebridge after saving.

## AirPlay streaming

Raumfeld speakers are **not** native AirPlay receivers, so the plugin bridges the
gap: it runs a [`shairport-sync`](https://github.com/mikebrady/shairport-sync)
process per zone (that's the AirPlay target your iPhone sees), captures the
decoded audio, and re-serves it to the zone's renderer over HTTP.

**Prerequisite — install `shairport-sync` on the Homebridge host** (built with the
`stdout` backend, which the common packages include):

```sh
# Debian/Ubuntu/Raspberry Pi OS
sudo apt install shairport-sync
# macOS
brew install shairport-sync
```

Then in `config.json`, `airplay.enabled: true` (the default). Zones appear in the
iOS AirPlay / Control-Center output picker. Selecting one points that Raumfeld
zone at the plugin's stream and starts playback; a grouped zone plays through its
lead renderer and Raumfeld keeps the member speakers in sync.

### Set a password

By default the receivers are **open**: any device on your network — a guest on
the same Wi-Fi, a compromised IoT gadget — can play audio through your speakers
without authenticating. Set `airplay.password` to require a password in the iOS
picker:

```json
"airplay": { "enabled": true, "password": "your-password" }
```

The password is handed to `shairport-sync` as a command-line argument, so it is
visible to other local users of the Homebridge host (via `ps`). It is redacted
in the Homebridge log. If your host is shared with people you don't trust at the
OS level, that tradeoff is worth knowing about.

Notes and limits:

- **Different subnets:** the speakers pull the audio stream **from** the
  Homebridge machine, so that machine's stream host/port must be reachable from
  the speakers. Auto-detection picks the first LAN IP; set `airplay.streamHost`
  (and open `airplay.streamPort`) if that guess is wrong.
- Each zone runs its own receiver in **AirPlay-1 mode** (one self-contained
  process per zone). AirPlay-2 multi-room grouping across zones is not attempted.
- If `shairport-sync` isn't installed, AirPlay stays off and the plugin logs a
  one-time warning — everything else works normally.

## Multiroom behaviour

Groups are **authored in the Raumfeld app**, not in Homebridge — the plugin
mirrors them live. When rooms are combined into a Raumfeld group:

- the group is exposed as **one** accessory (the controllable unit);
- each member room stays visible but its writes are **routed to the group lead**, so controlling it controls the group;
- dissolve the group in the Raumfeld app and the rooms become individually controllable again.

## Tested with

Stereo L · Stereo M · One · One M · Stream · Soundbar · Connector

## Requirements

- Node.js ≥ 18
- Homebridge ≥ 1.8 (Homebridge 2.0 ready)
- A Raumfeld host (any Raumfeld/Teufel speaker or Connector acting as host) reachable on port `47365`
- *(AirPlay only)* `shairport-sync` installed on the Homebridge host — see [AirPlay streaming](#airplay-streaming)

## Development

The plugin sources live in this directory.

```sh
npm install
npm run build       # rimraf ./dist && tsc
npm run lint
npm run dev         # nodemon: rebuild + relaunch Homebridge against test/hbConfig
```

Architecture: a dynamic platform (`src/platform.ts`) mirrors the host’s rooms and
zones as accessories; `src/raumfeldClient.ts` talks to the host HTTP API
(`/getZones`, `/listDevices`, long-poll `updateId`) and drives each renderer over
SOAP (RenderingControl / AVTransport); `src/zoneAccessory.ts` is the per-accessory
HomeKit service; `src/airplayBridge.ts` orchestrates AirPlay — spawning a
`shairport-sync` receiver per zone (`src/airplayReceiver.ts`) and re-serving its
PCM to the renderer through a small HTTP stream server (`src/airplayStreamServer.ts`).

## License

MIT © Alexander Peither
